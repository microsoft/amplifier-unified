import{c as r,s as e}from"./flowDiagram-HODETNUW-CNZEtemo.js";import{_ as a}from"./mermaid.core-DbMKSlqP.js";import"./chunk-5VM5RSS4-C0z2Mr3K.js";import"./chunk-XXDRQBXY-D4PYBWb-.js";import"./chunk-POPQ4Y6H-A_7sJxXr.js";import"./chunk-F27PBJKO-P3ii5AU8.js";import"./app-D8pVmLJg.js";import"./client-BPXDbY79.js";import"./channel-BbEdIXl_.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};

const s="/assets/babylon-Ck7fWz8i.js";export{s as default};

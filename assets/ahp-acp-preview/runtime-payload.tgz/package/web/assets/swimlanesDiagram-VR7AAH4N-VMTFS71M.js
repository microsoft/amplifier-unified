import{c as r,s as e}from"./flowDiagram-HODETNUW-pYQ4t2WD.js";import{_ as a}from"./mermaid.core-CmZ08PSt.js";import"./chunk-5VM5RSS4-COJ08cbQ.js";import"./chunk-XXDRQBXY-BLdBS8DJ.js";import"./chunk-POPQ4Y6H-Bi8RSRWt.js";import"./chunk-F27PBJKO-C2b9OMSv.js";import"./app-bmiKPFJE.js";import"./client-BPXDbY79.js";import"./channel-D0cjY8HS.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};

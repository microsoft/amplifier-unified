import{c as r,s as e}from"./flowDiagram-HODETNUW-CW7x1juR.js";import{_ as a}from"./mermaid.core-4J_xNgcL.js";import"./chunk-5VM5RSS4-DaQXI4DM.js";import"./chunk-XXDRQBXY-DZMaTSF6.js";import"./chunk-POPQ4Y6H-B8rWrlU4.js";import"./chunk-F27PBJKO-BKxNayoH.js";import"./app-C6Yzb7Qs.js";import"./client-BPXDbY79.js";import"./channel-BUMnC_PH.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};

import{c as r,s as e}from"./flowDiagram-HODETNUW-C6Cg1p3p.js";import{_ as a}from"./mermaid.core-8uepqZVr.js";import"./chunk-5VM5RSS4-i-0hvdhI.js";import"./chunk-XXDRQBXY-BqvX0I3w.js";import"./chunk-POPQ4Y6H-CxFVoPZA.js";import"./chunk-F27PBJKO-DUBMX78v.js";import"./app-D2nAntnz.js";import"./client-BPXDbY79.js";import"./channel-B59WGYjU.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,y=r({defaultLayout:"swimlane",styles:m});export{y as diagram};

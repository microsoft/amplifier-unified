import{ah as o,ai as n}from"./mermaid.core-8uepqZVr.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};

import {forwardAdmissionAbort,recordAdmissionRefusal} from './admission-abort.js';
import {retentionParticipant} from './retention.js';
import {validateServiceRelease} from './service-lifecycle.js';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
const serviceFields=['installationId','dataScope','ownerId','instanceId','releaseDigest'];
function addServiceIdentity(result,value){if(result.purpose==='service-stop'){const identity=value.serviceIdentity;if(!identity||Array.isArray(identity)||Object.keys(identity).length!==serviceFields.length||serviceFields.some(key=>typeof identity[key]!=='string'||!identity[key]||identity[key].length>200||/[\x00-\x1f]/.test(identity[key]))||identity.instanceId!==result.instanceId||identity.dataScope!==result.dataScope)throw Error('Exact bounded service identity required');result.serviceIdentity=Object.fromEntries(serviceFields.map(key=>[key,identity[key]]));}else if(value.serviceIdentity!==undefined)throw Error('Service identity requires service-stop purpose');return result;}
const canonical=value=>Array.isArray(value)?value.map(canonical):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(key=>[key,canonical(value[key])])):value;
const signature=(context,outcome,proof)=>JSON.stringify(canonical({context,outcome,proof}));
function parseOwnerFrame(line){
 const row=JSON.parse(line);
 if(!row||typeof row!=='object'||Array.isArray(row)||row.jsonrpc!=='2.0')throw Error('Malformed owner envelope');
 if(row.method!==undefined){
  if(typeof row.method!=='string'||!row.params||typeof row.params!=='object'||Array.isArray(row.params))throw Error('Malformed owner notification or callback');
  if(!['owner/idle','owner/changed'].includes(row.method)&&!['string','number'].includes(typeof row.id))throw Error('Malformed owner callback identity');
 }else if(!Number.isSafeInteger(row.id)||Object.hasOwn(row,'result')===Object.hasOwn(row,'error')||(Object.hasOwn(row,'error')&&(!row.error||typeof row.error!=='object'||typeof row.error.message!=='string'||!Number.isInteger(row.error.code))))throw Error('Malformed owner reply');
 return row;
}
function ownerTimeout(launcher,initialize=false){
 const value=initialize?(launcher.initializeTimeoutMs??15000):(launcher.requestTimeoutMs??90000);
 if(!Number.isInteger(value)||value<25||value>90000)throw Error('Owner timeout must be25–90000ms');
 return value;
}
export class Peer{
 constructor(launcher,changed,idle){this.launcher=launcher;this.changed=changed;this.idle=idle;this.pending=new Map();this.next=0;this.calls=0;this.releaseBarrier=null;this.waitingReads=0;this.drainListeners=new Set();this.closed=false;this.releases=new Map();}
 signal(fn){try{Promise.resolve(fn?.()).catch(()=>{})}catch{}}
 fail(message){this.closed=true;for(const entry of this.pending.values()){clearTimeout(entry.timer);entry.reject(Error(message))}this.pending.clear();this.signalDrain();if(this.held)this.held.state='unknown';}
 async start(){if(this.closed)throw Error('Diagnostics owner closed; no replay');if(!this.ready)this.ready=(async()=>{const child=this.child=spawn(this.launcher.command,this.launcher.args??[],{cwd:this.launcher.cwd,env:{...process.env,...this.launcher.env},stdio:'pipe'});child.stdin.on('error',()=>{this.fail('Owner input transport failed; outcome unknown');child.kill();});child.stderr.on('data',()=>{});child.on('error',()=>this.fail('Diagnostics owner failed to start'));child.on('close',()=>this.fail('Diagnostics owner closed; uncertain sends not replayed'));let bytes=0;child.stdout.on('data',chunk=>{for(const byte of chunk){bytes=byte===10?0:bytes+1;if(bytes>131072){this.fail('Diagnostics frame exceeded128KiB');child.stdout.destroy();child.stdin.end();child.kill();}}});createInterface({input:child.stdout}).on('line',line=>{if(this.closed)return;let row;try{row=parseOwnerFrame(line)}catch{this.fail('Malformed diagnostics frame; outcome unknown');child.kill();return;}if(row.method==='owner/changed'){this.signal(this.changed);return}if(row.method==='owner/idle'){this.signal(this.idle);return}const entry=this.pending.get(row.id);if(!entry)return;this.pending.delete(row.id);clearTimeout(entry.timer);row.error?entry.reject(Object.assign(Error(row.error.message),{knownRefusal:row.error.data?.knownRefusal===true})):entry.resolve(row.result);this.signalDrain();this.signal(this.idle);});const info=await this.send('initialize',{});if(info.protocolVersion!==1||!info.quiescence?.heldIntake||!info.quiescence?.durableRelease)throw Error('Diagnostics owner lacks required protocol/fence contract');this.serviceSupported=info.quiescence?.serviceStop?.version===1})().catch(error=>{this.fail('Diagnostics owner initialization failed; no replay');this.child?.kill();throw error;});return this.ready;}
 send(method,params){if(this.closed||!this.child)throw Error('Diagnostics owner unavailable');if(this.pending.size>=64)throw Error('Diagnostics request capacity reached');const id=++this.next,data=JSON.stringify({jsonrpc:'2.0',id,method,params})+'\n';if(Buffer.byteLength(data)>131072)throw Error('Diagnostics frame exceeds128KiB');return new Promise((resolve,reject)=>{const entry={resolve,reject};entry.timer=setTimeout(()=>{this.fail('Owner reply timed out; outcome unknown, not replayed');this.child?.kill();},ownerTimeout(this.launcher,method==='initialize'));entry.timer.unref();this.pending.set(id,entry);this.child.stdin.write(data,error=>{if(error)this.fail('Diagnostics transport lost; uncertain sends not replayed')});});}
 async request(method,args){
  if(this.held&&!(method==='snapshot'||method==='action'&&['diagnostics.get','diagnostics.records','diagnostics.environment','diagnostics.receipt'].includes(args.operation)))return {accepted:false,executed:false,reason:'Diagnostics intake held'};
  if(this.releaseBarrier){if(this.waitingReads>=64)throw Error('Diagnostics release wait capacity reached');this.waitingReads++;try{while(this.releaseBarrier)await this.releaseBarrier;}finally{this.waitingReads--;}}
  if(this.held&&!(method==='snapshot'||method==='action'&&['diagnostics.get','diagnostics.records','diagnostics.environment','diagnostics.receipt'].includes(args.operation)))return {accepted:false,executed:false,reason:'Diagnostics intake held'};
  this.calls++;try{await this.start();return await this.send(method,args)}finally{this.calls--;this.signalDrain();this.signal(this.idle)}
 }
 signalDrain(){if(!this.calls&&!this.pending.size)for(const notify of this.drainListeners)notify();}
 drainReads(){
  if(!this.calls&&!this.pending.size)return Promise.resolve();
  return new Promise((resolve,reject)=>{const done=()=>{clearTimeout(timer);this.drainListeners.delete(done);resolve();};
   const timer=setTimeout(()=>{this.drainListeners.delete(done);reject(Error('Diagnostics reads did not settle; protection remains held'));},Math.min(this.launcher.requestTimeoutMs??10000,10000));this.drainListeners.add(done);});
 }
 release=async(input,outcome,proof,liveRollback=false)=>{
  // Hold new refreshes while existing reads drain. Mutations remain fenced and
  // the original authenticated release proof is still checked by the owner.
  while(this.releaseBarrier)await this.releaseBarrier;
  let resume;this.releaseBarrier=new Promise(resolve=>{resume=resolve;});
  try{await this.drainReads();return await this.releaseNow(input,outcome,proof,liveRollback);}
  finally{this.releaseBarrier=null;resume();}
 };

 inspectQuiescence=async()=>{await this.start();return this.send('quiescence/inspect',{})};
 context(value){const result={};for(const key of ['fenceId','commandId','purpose','instanceId','dataScope']){if(typeof value[key]!=='string'||!value[key]||value[key].length>200)throw Error('Bounded exact diagnostics fence required');result[key]=value[key]}return addServiceIdentity(result,value);}
 acquire=async input=>{const context=this.context(input);await this.start();if(context.purpose==='service-stop'&&!this.serviceSupported)throw Error('Owner does not support service-stop');if(this.calls||this.pending.size){if(context.purpose==='distribution-update')await recordAdmissionRefusal((method,params)=>this.send(method,params),context);return null;}if(this.held&&(this.held.state!=='held'||JSON.stringify(this.held.context)!==JSON.stringify(context)))throw Error('Diagnostics fence requires explicit reconciliation');this.held={context,state:'checking'};try{await this.start();const result=await this.send('quiescence/acquire',context);if(result.acquired!==true){if(result.executed===false){this.held=undefined;return null}throw Error('Diagnostics intake outcome unknown')}if(result.fenceId!==context.fenceId||result.intakeClosed!==true)throw Error('Exact diagnostics fence not confirmed');this.held.state='held';return {ownerId:'diagnostics',fenceId:context.fenceId,release:(outcome,proof)=>this.release(context,outcome,proof,true)}}catch(error){if(this.held)this.held.state='unknown';throw error}};
 abortAdmission=async input=>{const context=this.context(input);if(this.calls||this.pending.size)throw Error('diagnostics requests are still in flight');await this.start();const result=await forwardAdmissionAbort((method,params)=>this.send(method,params),input,'diagnostics','quiescence/abortAdmission');if(this.held&&signature(this.held.context)===signature(context))this.held=undefined;return result};
 releaseNow=async(input,outcome,proof,liveRollback=false)=>{const context=this.context(input),identity=signature(context,outcome,proof),priorRelease=this.releases.get(context.fenceId);if(priorRelease){if(priorRelease!==identity)throw Error('Exact retained Diagnostics release proof required');return}if(this.calls||this.pending.size)throw Error('Diagnostics requests are still in flight');if(this.held&&signature(this.held.context)!==signature(context))throw Error('Diagnostics fence changed');const rollback=liveRollback&&this.held?.state==='held'&&outcome==='unchanged'&&proof?.kind==='admission-refused'&&Object.keys(proof).length===1;if(context.purpose==='service-stop'&&outcome!=='unknown'&&!rollback)validateServiceRelease(context,outcome,proof);const before=this.held;await this.start();if(context.purpose==='service-stop'&&!this.serviceSupported)throw Error('Owner does not support service-stop');this.held={context,state:'unknown'};let result;try{result=await this.send('quiescence/release',{...context,outcome,proof})}catch(error){if(error.knownRefusal)this.held=before;throw error}if(outcome==='unknown')return;if(result.released!==true||result.intakeClosed!==false)throw Error('Diagnostics intake release unconfirmed');this.held=undefined;this.releases.set(context.fenceId,identity);if(this.releases.size>64)this.releases.delete(this.releases.keys().next().value)};

 get participant(){return retentionParticipant({id:'diagnostics',serviceStop:{version:1},acquire:this.acquire,abortAdmission:this.abortAdmission,reconcileRelease:input=>this.release(input,input.outcome,input.proof)},args=>this.send('quiescence.retention',args))}
 async close(){
  const child=this.child;this.fail('Owner closed; uncertain work was not replayed');
  if(!child||child.exitCode!==null||child.signalCode!==null)return;
  child.stdin.end();await new Promise(resolve=>{const timer=setTimeout(()=>{child.kill('SIGKILL');resolve()},4000);child.once('close',()=>{clearTimeout(timer);resolve()})});
 }
}

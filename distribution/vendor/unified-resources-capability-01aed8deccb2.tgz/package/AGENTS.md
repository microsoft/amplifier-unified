# Resources owner entry point

Read [local vision](docs/VISION.md), [contract v1](docs/CONTRACT.v1.md) and
[README](README.md) before changes. The approved family direction remains owned
by the distribution; upstream AHP/ACP semantics remain authoritative. Keep changes
inside resources ownership and propose cross-owner semantics to the coordinator.

Preserve original IDs, bodies, versions, histories and truthful unknown outcomes.
Keep small updates scoped and private client presentation outside this owner.
Run relevant executable checks mapped by the contract. Report source, installed
package, actual peer, browser/device/account and deployment evidence separately.
Do not self-ratify new scope or weaken desired behavior to match existing tests.

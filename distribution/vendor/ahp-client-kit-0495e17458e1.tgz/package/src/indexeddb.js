// Browser adapter for the client kit storage interface. No host network activity.
export class ScopedIndexedDBStore {
 constructor({host,account,tab,database='amplifier-client-state',indexedDB=globalThis.indexedDB}){if([host,account,tab].some(value=>typeof value!=='string'||!value))throw Error('Host, account and tab identity are required');this.database=database;this.scope=JSON.stringify([host,account,tab]);this.indexedDB=indexedDB;this.tail=Promise.resolve();}
 async open(){if(this.db)return this;if(this.opening)return this.opening;this.opening=(async()=>{this.db=await new Promise((resolve,reject)=>{if(!this.indexedDB)return reject(Error('Private storage is unavailable. Your drafts cannot survive a restart.'));const request=this.indexedDB.open(this.database,1);request.onupgradeneeded=()=>request.result.createObjectStore('records');request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error)});return this;})();try{return await this.opening}finally{this.opening=null;}}
 key(key){return `${this.scope}:${key}`}
 async read(key){await this.open();return new Promise((resolve,reject)=>{const request=this.db.transaction('records').objectStore('records').get(this.key(key));request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error)});}
 write(key,value){const operation=this.tail.then(async()=>{await this.open();await new Promise((resolve,reject)=>{const tx=this.db.transaction('records','readwrite');tx.objectStore('records').put(value,this.key(key));tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('Private storage transaction aborted'))});});this.tail=operation.catch(()=>{});return operation;}
 close(){this.db?.close();this.db=null;}
}

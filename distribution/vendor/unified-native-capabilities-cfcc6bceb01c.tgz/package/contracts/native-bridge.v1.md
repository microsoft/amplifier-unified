# Native capability bridge contract — v1

Status: local declaration of inherited approved direction and existing public
interfaces; **no new family ratification or proposed runtime scope**. Parent:
[local vision](../docs/VISION.md). Shared authority: family contracts at
[`625af2f`](https://github.com/microsoft/amplifier-unified/tree/625af2f2832fafc8152f6078061d626f160362a4/contracts).
The schema owners define wire details; this document does not copy them.

## Public boundary and consumers

`createNativeCapabilities` supplies manifest discovery, `actionSchemas`, bounded
`read`, scoped `action`, and lazy `invalidate`. `AdminConnection` supplies trusted
`perform`, narrow import/maintenance composition and one administration quiescence
participant. `createPermissionsCapabilities` supplies the separate scoped file
preference bridge. Their authoritative declarations live in exported package
types and `src/action-schemas.ts` / `src/permissions.ts`, not prose copies here.

[Upstream AHP](https://microsoft.github.io/agent-host-protocol/) and
[ACP](https://agentclientprotocol.com/) own standard protocol semantics. Native
`_amplifier/native` and `_amplifier/admin` extensions and their negotiated metadata
belong to `amplifier-app-acp`. This product bridge neither redefines standard
model/mode controls nor owns native storage. Optional absence is explicit.

## Promises and falsifiers

The following promises inherit the linked family clauses. Acceptance links point
to the sealed implementation source; they are checks, not universal parity claims.

| Local promise | Shared basis | Falsifier and executable evidence |
| --- | --- | --- |
| NB1: Keep native execution/settings behind negotiated ACP; preserve modular composition. | [CB2–3](https://github.com/microsoft/amplifier-unified/blob/625af2f2832fafc8152f6078061d626f160362a4/contracts/component-boundaries.v1.md), [AP1–2, AP5](https://github.com/microsoft/amplifier-unified/blob/625af2f2832fafc8152f6078061d626f160362a4/contracts/agent-protocol.v1.md) | A TypeScript native store, fabricated absent catalog or silently substituted control breaks this boundary. [Provider tests](https://github.com/microsoft/amplifier-unified-capability-native/blob/b33432cb967c21a6840a8155013c71ab7f173940/test/provider.test.ts) and [installed presentation](https://github.com/microsoft/amplifier-unified-capability-native/blob/b33432cb967c21a6840a8155013c71ab7f173940/test/installed-presentation.test.ts). |
| NB2: Bind actions to trusted context; retain one native administration authority. | [HP4–5](https://github.com/microsoft/amplifier-unified/blob/625af2f2832fafc8152f6078061d626f160362a4/contracts/host-protocol.v1.md), [CS1, CS5, CS7](https://github.com/microsoft/amplifier-unified/blob/625af2f2832fafc8152f6078061d626f160362a4/contracts/client-state.v1.md) | Foreign selectors, caller-supplied homes or forged tool actors must not authorize dispatch. [Permission tests](https://github.com/microsoft/amplifier-unified-capability-native/blob/b33432cb967c21a6840a8155013c71ab7f173940/test/permissions.test.ts), provider scope/actor cases and admin fence cases. |
| NB3: Preserve saved/mounted distinctions and truthful refusal/unknown outcomes without replay. | [AP4](https://github.com/microsoft/amplifier-unified/blob/625af2f2832fafc8152f6078061d626f160362a4/contracts/agent-protocol.v1.md), [HP6](https://github.com/microsoft/amplifier-unified/blob/625af2f2832fafc8152f6078061d626f160362a4/contracts/host-protocol.v1.md), CS4–6 | Throwing away a completed save after lost activation, rebasing stale CAS or retrying uncertain work breaks this promise. Provider causal save/CAS cases and [actual runtime checks](https://github.com/microsoft/amplifier-unified-capability-native/blob/b33432cb967c21a6840a8155013c71ab7f173940/test/runtime.integration.test.ts). |
| NB4: Bound selected projections and leave drafts with clients. | [WS3–5](https://github.com/microsoft/amplifier-unified/blob/625af2f2832fafc8152f6078061d626f160362a4/contracts/working-set.v1.md), CS2–3 | An unrelated history scan, eager global rebuild, leaked editor selection or unbounded scope cache violates this direction. Provider lazy/copy/invalidation checks and permission projection checks. Whole-app scale remains separately qualified. |
| NB5: Preserve native held intake and exact trusted recovery scope. | CB7, CS7, [MA](https://github.com/microsoft/amplifier-unified/blob/625af2f2832fafc8152f6078061d626f160362a4/contracts/maintenance.v1.md) | A detached callback, replacement process or browser selector cannot recreate a maintenance lease. [Admin tests](https://github.com/microsoft/amplifier-unified-capability-native/blob/b33432cb967c21a6840a8155013c71ab7f173940/test/admin.test.ts) cover release binding, capture, cache and app-reset gates. |
| NB6: Keep user/agent semantics and evidence limits explicit. | [CX3, CX7](https://github.com/microsoft/amplifier-unified/blob/625af2f2832fafc8152f6078061d626f160362a4/contracts/client-experience.v1.md), [CD3, CD5–6](https://github.com/microsoft/amplifier-unified/blob/625af2f2832fafc8152f6078061d626f160362a4/contracts/client-development.v1.md), CB4–5 | A source fixture called browser/account/release acceptance, or forged caller actor, falsifies the claim. Installed runtime checks exercise actual approved UI/agent tool calls; exact peer/package receipts retain gaps. |

## Consumer obligations already required by this boundary

Hosts authorize channels and workspaces before calling these ports, retain the
original command identity, and distinguish a delivered completed-save response
from its activation outcome. The additive bundleCommands v1 binding delegates
exact child results to native-owned receipts; host status/detail and topic caches
cannot substitute for those results. Composition must resolve actual negotiated
metadata asynchronously and bind a separate passive selected-session receipt
port; a static caller capability assertion or active runtime-control fallback
cannot establish support. Save and activation use distinct stable child identities.
Passive receipt inspection returns native unknown/refusal/needs-model outcomes
without replay or inferred completion. Hosts preserve the original canonical
history/admin workspace across restart; relocated execution directories or a
changed current default do not replace that binding. A null receipt in a different
workspace cannot close the original command. Host-scope recovery after a default
change without retained original authority remains unqualified.
The [installed successor fixture](../test/bundle-receipts.integration.test.ts)
qualifies exact native child recovery across process restart and wrong-scope
lookups; host transport/browser recovery remains separate. Consumers keep
native configuration revisions opaque and require explicit stale-draft review.

Composition binds every administration callback to the same genuine connection
and quiescence participant. Only trusted host recovery code enters the matching
maintenance fence; native paths and private reset DTOs do not become browser
arguments. Clients retain private drafts and render needs-model, failed and
unknown outcomes without automatic mutation retries. They inspect negotiated
support before exposing optional controls.

## Optional peer availability

Native administration remains optional for generic host/history and other engine
access. A bounded passive initialization failure is `unavailable`, not a permanent
unsupported claim or a rejected promise shared by unrelated schemas/controls.
Admin-backed reads expose availability without invented empty catalogs. Receipt
advertisement is stable for an instance; explicit reconstruction after the peer
is restored renegotiates passive metadata without retrying effects. The native
receipt store, held intake and unresolved outcomes retain their authority.

Native bundle v1 refused or unknown receipts may include optional
`diagnosticReceipt`, exactly a 44-character `startup-` plus 32 lowercase hex
digits plus `.log` private worker-log basename. The bridge preserves this native
pointer without reading that file, exposing an absolute path or changing the
original outcome. Succeeded receipts forbid the field. Unknown still forbids
completion, execution proof, reason and result fields; existing stored receipts
remain unchanged. Native owns creation and filtering of the diagnostic pointer.

## Qualification and open gaps

`npm test` and `npm run check` cover the local owner. Set `AMPLIFIER_ACP_PYTHON` for
actual installed native checks; omitted peers produce visible skips. Set
`AMPLIFIER_NATIVE_CAPABILITY_MODULE` for an independently installed package.
Enable `AMPLIFIER_TEST_NATIVE_APPROVAL=1` with repaired native `473d42f`; enable
`AMPLIFIER_TEST_PORTABLE_BUNDLE=1` with the native owner's test-only installed
provider fixture. These flags qualify fresh owned state, never retry old effects.

Implementation `b33432c` passed 38 source and 38 installed consumer checks with no
skips on macOS against native `473d42f`. Three causal bundle-save cases fail on
baseline `8e8b615`. The original `f530` approval deadlock/unknown records remain
retained independently. Hosted Node 22/24 fixture success is distinct from actual
native, browser, account and deployed acceptance.

Successor source and independently installed consumer suites each pass 45 checks
with zero skips against native `4d2ea06`; the older-peer refusal case uses sealed
`a434719`. The receipt fixture covers lost save/activation replies, native/admin
restart, exact unapplied model choice, wrong workspace/native identity and no
active-runtime recovery.

F04/F06–F10/F23/F25 retain their original desired behavior. Browser editors,
actual host transport lost-reply recovery and its UI, remote source discovery, nonempty skills/agents, supported
mode-set variants, all module/provider combinations, Linux installed-native,
real accounts/devices and live adoption are not established by this packet.
General global-agent administration policy remains a cross-owner question;
permission saves already restrict agents to their authorized session workspace.
No new policy or retirement decision is inferred from that gap.


## Mode projection consistency

After a completed `mode.set` or `mode.clear`, the selected runtime's cached
`mode.list` must reflect the complete native list response, preserving catalog
order and public fields. The mutation response and original command metadata
remain unchanged. If a peer supplies only a partial mutation response, the
bridge reads that selected runtime's public `mode.list` once; an unavailable or
incomplete read replaces stale mode truth with an explicit unavailable
projection. It never retries the completed mutation. Provider regression checks
cover load/set/clear for UI and agent origins and partial-response read failure;
actual mode-hook/browser acceptance belongs to the assembled consumer.

## Reviewed history-preserving context clear

Hosts await `negotiateContextClear()` before manifest composition. All three
`runtime-control` actions — `context.clear.review`, `context.clear`, and
`context.clear.receipt` — require actual negotiated `native.contextClear` v1
metadata and an injected passive receipt port. Missing, older or unavailable
peers leave them unadvertised; optional negotiation failure cannot poison an
unrelated engine. Generic `runtime.control` clear/review paths always refuse
before dispatch, including on older peers.

Review takes no arguments. Apply takes only the exact reviewed history and
control revisions; the original public action envelope supplies command identity.
The bridge derives a stable native command from the AHP session scope and that
original identity. Native owns canonical history, preserved segments/events,
explicit goal clearing, active-task refusal, revision checks, and exact outcomes.
The native `context-clear.v1.json` and `context-clear-receipt.v1.json` schemas
own closed wire objects and the 16 KiB result/receipt bound.

`nativeContextClear` supplies actual initialization metadata;
`nativeContextReceipt` resolves the authenticated original AHP scope to an
admitted configured native engine, immutable native session ID and canonical
history workspace. A relocated execution workspace or changed current default
cannot replace that authority. `AdminConnection.contextClearCapabilities()` and
`readContextReceipt({sessionId,cwd,commandId})` are passive adapter ports; receipt
inspection must not admit a session, start a worker or invoke `nativeControl`.

Receipt results retain the original public command identity and native DTO under
`receipt`, including its derived native command ID. Null means no receipt,
not proof of an outcome. Unknown never acquires synthetic results or a current
state classification. Refused and succeeded outcomes retain their native fields.
Receipt inspection has no projection updates or invalidations. Apply failures
remain the original native error; no current-state read or mutation retry follows
an uncertain outcome. A completed apply response is preserved verbatim with the
original public command metadata.

Confirmed completion deletes the previous review and goal get/set/clear projections and
invalidates selected topics. It does not synthesize a `goals.get` result; clients
may explicitly refresh that read after completion. Passive receipt inspection
never changes current goal truth, which may have changed after the original clear.

## Preview refusal and generation grant

Every advertised native capability action and the separate permissions owner
preserve the selected native operation rejection carrying explicit `executed:false`,
without contradictory unknown or applied proof, as `accepted:false`, no updates or invalidations, and the copied native
fields plus `applied:false` and the original message. The public command metadata
remains unchanged. Other errors propagate unchanged; neither error wording nor
RPC codes establish absence of effects. Refusal never triggers refresh or replay. The proof must come from the selected
operation port, never a preparatory read or a post-success projection callback.
Task and configuration refusals retain the full native fields. Permission projection
listener failure cannot discard a confirmed successful save.

A closed administration connection emits `native-admin-connection-closed` only
for a new request blocked before dispatch. That rejection leaves every previous
receipt unchanged; a prior lost reply remains unknown. Original IDs are never
resent and the connection is never automatically restarted. Prompt/turn failures
are owned by native execution and the host admission path; this package cannot
classify them from exception names or provider error text.

Standard ACP model choices are opaque identifiers owned by the host configuration
route. Clients submit advertised choices through that route. The alternate native
provider selector forwards instance, model and effort fields without interpreting
those opaque identifiers.

`AdminConnection.generationsCapabilities()` passively returns a clone of actual
initialized `native.admin.generations` metadata. Every `generations.*` call requires
its version 1 grant; absent or unsupported grants refuse before admin dispatch
with `executed:false`, `replayed:false`, and `native-generations-unavailable`.
This connection never enables the launcher grant. Maintenance permission alone
does not grant generation operations.

## Passive account-bound message metadata

`createMessageCapabilities(options)` returns `{connection,capabilities}`. Trusted
root composition supplies its gateway account and a `resolveSession(context)`
callback returning the authorized AHP URI, immutable native session ID and canonical
history `workingDirectory`. Client arguments contain neither actor nor paths.
The connection sends exactly `clientCapabilities._meta['amplifier.dev/messagePrincipal']`
`{version:1,account}` alongside native v1 in ACP initialization. This is a trusted
spawned-stdio assertion, not independent authentication. Standalone peers without
the binding leave the optional capability absent. Root awaits `capabilities.negotiate()`
before composition; unsupported peers advertise no message actions or topic.

The independent passive connection requires no admin grant. Its first bounded
canonical history read binds the selected native ID before reaction and metadata reads.
An exact `message.receipt` uses the negotiated account and trusted immutable native
ID directly, without reading current history or establishing a mutation binding.
Committed, refused, unknown and null native receipts remain unchanged even when
the original workspace is unavailable. A fenced or uncertain connection remains
closed to new requests; cold receipt inspection does not clear it. It
never creates, loads or resumes a session, requests a worker, or calls nativeControl.
`message.reaction` takes an exact native `reference`, supported `emoji` and desired
boolean `present`; the public command envelope supplies the native command ID.
`message.read` takes up to 50 selected IDs, and `message.receipt` takes the exact
original command ID. Native owns reference freshness, metadata transactions,
account isolation and receipts. Unknown never authorizes replay. Explicit native
no-effect errors remain rejected capability results with their original fields.

The optional session-scoped `message-metadata` topic holds only `available` and the
last native `changedMessage` delta, with 32 cached scopes. Native notifications
map only to an already authorized binding and invalidate that selected interest.
Responses and notifications for the same message revision deduplicate. Read and
receipt actions never publish changes. Every topic read validates the protected
account and resolves only the public host mapping; negotiated quote support adds
`quote:{available:true,referenceMeta:"amplifier.dev/history.messageReference",maxChars:4000}`
for the verified selected engine, otherwise `quote:{available:false}`. No native
RPC or worker is needed for this dormant-session descriptor. Clients read selected metadata explicitly;
this topic is not a full history or annotation inventory.

Both returned objects expose the same `quiescenceParticipant`, default ID
`native-message-metadata`, plus `activity()` and `close()`. Root registers the
participant as required and maps all message actions to it. Initialization, history
binding and every message RPC count as in-flight work. Acquisition refuses while
busy, closed or uncertain; a held fence blocks all new native RPCs. Exact trusted
release proofs are required, including service-specific proofs. A release marked
unknown (or a rejected release attempt) retires the live pre-effect
`admission-refused` rollback authority; only exact authenticated release proof can
settle that held fence. Close refuses in-flight or uncertain requests. `onMayBeIdle` is advisory.
This participant proves local intake only: root must retain the genuine shared
native-home writer authority for cross-process quiescence. The host may call `reconcileRelease` after replacement only with its authenticated
original fence context and release proof. Generic proof binds fence, command,
scope, outcome, receipt and running instance. Service proof also binds the full
installation, platform owner, release and original instance: ready requires a
distinct replacement plus resume/exit/readiness receipts; unchanged requires the
original instance and a no-effect stop-refusal receipt. A digest or caller
assertion is not proof. The host authenticates platform evidence and retains the
genuine native-home authority among required owners; a fresh connection proves
only its own idle intake, never that an orphan finished.

Cold reconciliation validates proof before synthesizing a local held fence. It
performs no acquire, process startup, session/history read, native RPC or mutation.
Busy, closed or independently uncertain local intake refuses. Completed release
evidence is canonical, bounded to 32 KiB and cached for 256 fences: identical
lost-reply retries succeed, changed immutable context or proof refuses. Mutable
host phase/owner projections do not change the identity. Live
`admission-refused` is never valid cold proof. The causal production-host test
[message-release.test.ts](../test/message-release.test.ts) exercises persisted
21-owner fences, live and cold lost replies, service-specific proof validation
and unknown rollback rejection. Its other 20 owners and platform verifier are
fixture authorities; this does not qualify live platform exit or cross-process
native-home writer release.

Reply selection remains client-private. This provider advertises no reply/send
action. Only explicit Send may forward the exact flattened native reference under
prompt `_meta['amplifier.dev/messageReply']` with the original command metadata;
native validates and freezes the canonical bounded quote before admission.

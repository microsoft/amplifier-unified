"""Scoped media transport; no Amplifier engine or application-state dependency."""

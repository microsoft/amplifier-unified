# Amplifier Unified workspace capability

Workspace placement and shared registration are owned independently of clients,
agent runtimes, native history, and the repairable session catalog. This optional
owner supports existing-directory discovery, bounded workspace/session pages,
create, attach, display-name changes, and registration removal through the same
advertised actions for users and agents. No action deletes, moves, or overwrites
an existing directory or chat history. No read or mutation starts an agent.

The client owns selection, drafts, picker state, and navigation. A workspace may
have no loaded sessions. Removing the final registration is permitted; creation
and attachment remain available from the empty view. These replace the legacy
shared selectedWorkspaceId/settings.workspace and keep-at-least-one constraint.

## Packages and configuration

- Node: `@amplifier/unified-workspace-capability`, `createWorkspaceCapabilities`.
- Python: `amplifier-unified-workspaces`, executable
  `amplifier-unified-workspaces --config /absolute/owner.json`.
- Catalog: public long-lived `amplifier-session-catalog serve` with the workspace
  projection API. The Node host's `StdioCatalog` exports the required methods.
- Python owner requires POSIX directory handles and an exclusive process lease.
  The only Foundation dependency is the optional, native-independent `amplifier-operations` intake fence. There are no Core, AppService, or transcript imports.

```json
{
  "stateDirectory": "/private/unified/workspaces",
  "allowedRoots": ["/home/user/projects"],
  "defaultRoot": "/home/user/projects"
}
```

Both owner roots and host allowedWorkspaceRoots must permit the intended paths.
Paths are canonical, absolute, and checked against configured roots. The default
root may be absent; prepared creation safely allocates missing parents. Caller
arguments cannot change configured authority or select another owner database.

```js
const workspaces = createWorkspaceCapabilities({
  owner: {command: '/venv/bin/amplifier-unified-workspaces', args: ['--config', config]},
  catalog, // the same public StdioCatalog used by the AHP host
  onInvalidate: (topic, scope) => host.invalidateCapability(topic, scope),
  onMayBeIdle: () => coordinator.mayBeIdle(), // optional event-driven retry signal
});
// Compose manifest/read/action/actionSchemas with other optional capabilities.
// Close workspaces before closing the shared catalog.
```

## Public contract

The negotiated `workspaces` host topic uses standard resourceRead/resourceWatch:
`amplifier-capability://workspaces/workspaces`. A read returns
`{topic:'workspaces',scope:'host',revision,data:{workspaces:{items,nextCursor?,coverage,defaultRoot,configRevision,creationSupported}}}`.
Topic revisions are safe integers. Each workspace is
`{id,name,path,available,availability,registered,hidden,revision,source,checkedAt}`;
IDs are `workspace:` plus SHA256 of the canonical path. Source is `registered` or
`discovered`; availability is `present`, `missing`, or `unknown`.

Actions use negotiated `x-amplifier/capabilityAction`, version 1, topic workspaces,
root channel (or the authenticated native caller's session), explicit commandId,
and the schemas returned by actionSchemas:

| Operation | Arguments | Result |
| --- | --- | --- |
| workspace.list | query?, cursor?, limit<=50, includeHidden?, includeUnavailable? | items, nextCursor?, coverage |
| workspace.inspect | id | current indexed workspace and explicit directory inspection |
| workspace.prepare | name, root? | planId, name, path, root, configRevision, disposition, workspaceId? |
| workspace.create | planId | created workspace and durable receipt |
| workspace.add | absolute path, name? | registered existing directory and receipt |
| workspace.rename | id, name, expectedRevision | display-name-only update and receipt |
| workspace.remove | id, expectedRevision | hidden registration and receipt |
| workspace.sessions | id?, query?, cursor?, limit<=50, parentUri?, archive? | standard AHP SessionSummary page |
| workspace.receipt | commandId | exact saved receipt; unknown allocation includes present inspection |
| workspace.pins | offset?, limit<=50, expectedRevision? | version, revision, complete authorized ids, bounded items, nextOffset |
| workspace.pin | id, pinned, expectedRevision | pinsRevision and durable receipt |
| workspace.pinOrder | ids, expectedRevision | pinsRevision and durable receipt |
| storage.inspect | scope?, rootId?, workspaceId?, path? | on-demand sizes for authorized roots or one relative folder |

Storage inspection uses a trusted `storageRoots` composition callback for app and
native-history roots and the shared catalog for workspace roots. Browsers cannot
choose arbitrary host roots. Native roots are negotiated from the actual peer;
older peers produce an explicit omission while workspace inspection still works.
Reads count file sizes, including hidden files, without reading their contents.
Hard links and overlapping roots do not inflate the overview total. Directory
descriptors anchor traversal; symbolic links are excluded. Scans are bounded to
200,000 entries, 1,000 roots and 2,000 rows per folder, with incomplete results
marked as lower bounds. Measurements occur only on demand, including while
maintenance holds new writes, and do not start an agent. Shared history and app
data have no deletion action in this view.

Workspace pins are shared owner preferences, independent of client selection,
conversation activity, and the session catalog. Empty registered workspaces can
be pinned. Missing directories keep their place and can be unpinned. Rename
preserves identity and order; explicit registration removal prunes its pin in the
same transaction. Neither pin action opens a session, reads history, or starts
an agent. Clients and agents use the same advertised actions.

The workspace topic includes only `pins:{version:1,revision}`; clients read
`workspace.pins` separately. It returns at most50 directory details and a
complete ordered ID vector bounded to10000 pins for exact reorder. Authorization
and hidden-registration filtering precede pagination. Only returned directory
details are inspected; no recursive filesystem or history scan occurs.
Subsequent offsets require the observed revision; a changed order requires a
fresh first page. Reorder includes every currently authorized pin exactly once
and preserves inaccessible preferences if configured roots have narrowed.
Pin commands allow at most1MiB, sufficient for the bounded vector; all other
workspace command limits remain unchanged.

Pin writes compare the exact shared pins revision. A stale client receives a
known refusal instead of overwriting another client's order. The preference and
completed receipt commit atomically. Duplicate command IDs return their receipt;
uncertain historical commands are never replayed. Corrupt preferences refuse
startup or reads while retaining the original authority. Pin reads are passive
under maintenance fences and pin writes use the ordinary owner intake gate.

### Importing existing workspace preferences

`amplifier-unified-workspaces-migrate --source /captured/app.sqlite3
--sha256 <reviewed-digest> --destination /new/inactive/workspaces
--config /reviewed/workspace-roots.json` creates a new inactive workspace owner
from a closed main-version application snapshot. The configuration contains
explicit `allowedRoots` and `defaultRoot`. An existing destination is refused;
the adapter never merges into a running owner or activates the result.

The reader understands both the older base state and current `state_records`
global overlays, including explicitly removed preferences. It preserves display
names and main's effective pin order, records old-to-new workspace identities,
and retains the exact original database with private permissions. Missing folders
remain registered without being created. Stale and duplicate pin IDs are filtered
using main's membership/first-occurrence semantics and counted in the receipt.
Unresolved paths, aliases that would merge distinct registrations, paths outside
the configured roots, malformed records and changed snapshots refuse before
publication. No catalog, conversation or agent is started.

For full workspace metadata, add `--metadata-manifest /captured/manifest.json`
and `--metadata-sha256 <reviewed-manifest-digest>`. The manifest is
`{"version":1,"files":{"workspace-starters.json":"<sha256>",
"workspace-setup/<setup-id>.json":"<sha256>",
"workspace-resources/<workspace-uuid-hex>.json":"<sha256>"}}` and must cover
every captured JSON record in those three locations beside it. Capture these
files only after the old application has stopped; review both the database and
manifest digests together. Each regular file, its size and digest are checked;
symlinks, omitted records, duplicate identities, changed bytes and mismatched
setup links refuse the entire import. A registration with `setupId` cannot be
imported without its reviewed metadata capture.

Custom starter definitions and completed command receipts retain their original
IDs, revisions and bytes. Resource inventory filenames follow the reviewed
workspace identity mapping; individual resources, statuses and evidence do not
change. Setup receipts retain exact directory identities and original steps.
Separate setup links expose these receipts without inventing allocation commands
or plans. Interrupted setup is displayed as interrupted and never auto-starts;
explicit retry still refuses uncertain Git outcomes. Future use of an old
starter rechecks currently configured bundles. Unassociated historical records
remain in the private `legacy-workspace-metadata` archive with the manifest.

Without a metadata manifest, the receipt explicitly limits coverage to names and
pins. Client selection and drafts remain client-owned. Original application
command receipts stay in the retained database; no legacy command becomes a
pending command or is replayed. Use the returned identity mapping when separately
reviewing client-state migration. This adapter does not activate an installation;
coordinated product migration and browser qualification remain separate checks.

Default list visibility is existing directories and non-hidden registrations;
filtering happens in SQL before keyset pagination. Both name and full path can be
searched. Cursors are connection/query-bound and expire. Concurrent label changes
can reorder later pages; restart paging for a newly sorted view. Sessions default
to root sessions; child pages require an explicit parent URI. Session summaries
omit native storage paths and IDs, and explicitly label runtime status unverified.
A missing directory is an availability fact, not deletion of its registration or
native data. Background catalog rechecks refresh availability; list queries do
not stat every directory or read native transcript/event bodies.

## Durable effects and recovery

Creation is a two-step prepare/create contract. Plans expire after 24 hours and
bind the configured root, normalized slug, collision result, and nearest existing
directory's device/inode. Create reserves its command and plan before mkdir,
walks pinned directory handles without following symlinks, and verifies the
created directory identity. Existing paths require explicit attachment; a second
plan for the same path never adopts another creator's directory implicitly.

The owner database is authoritative for registrations, plans, and receipts. A
process lease excludes concurrent owners of the same database. A command reused
with different arguments is rejected. Confirmed duplicate commands return their
saved result without repeating an effect. An interrupted process converts pending
admission to unknown, preserves partial directories, and never retries mkdir.
Receipt inspection is read-only and is not proof that an unknown directory was
created by this command. A user may inspect and explicitly attach that directory
with a new command. A new command on the same unresolved plan is also refused.

Mutation results disclose `filesDeleted:false` and `historyPreserved:true`.
Known pre-effect refusals return `accepted:false` with `executed:false` and a
rejected owner receipt. Unexpected failures after reservation and transport loss
remain unknown. Outer host receipt recovery and owner workspace.receipt are
separate: a completed owner command can repair a lost catalog projection without
repeating its filesystem effect.

The catalog stores only a derived label/visibility projection. Checkpointed
batches of at most 100 current registrations repair a lost catalog from the
owner. A catalog scanner or native restore cannot clear a user's hidden workspace
registration. Explicit attach restores discovery. This is visibility, not access
revocation: existing authorized session links and retained history remain usable.

## Held maintenance boundary

Register `workspaces.quiescenceParticipant` as required owner `workspaces`, and
map the `workspaces` capability topic to that owner in host coverage. Forward its
explicit `quiescenceAccess` map through composition: list, inspect, sessions and
receipt are passive reads; every other action remains ordinary mutation admission.
`onMayBeIdle` is a signal to the coordinator to recheck eligibility, not proof of
quiescence. It fires when Node requests/reverse callbacks and Python work settle.

The Node participant reserves intake before lazy process startup and counts the
entire request plus reverse catalog callback lifetime. The Python owner acquires
its existing OS process lease before opening the durable Foundation intake ledger.
It counts requests before lock waits, prepared mkdir intents, registration writes,
and the final catalog synchronization. A queued request or delayed catalog write
refuses acquisition. Only a confirmed private `quiescence/acquire` response creates
a held participant lease; there is no idle sampling or dormant agent startup.

Private RPCs `quiescence/inspect`, `quiescence/acquire` and `quiescence/release`
are coordinator-only. Context is `{fenceId,commandId,purpose,instanceId,dataScope}`.
Release requires the exact host-verified outcome and proof, or the narrowly scoped
admission-refused proof. Unknown release retains intake. The Foundation ledger
persists exact release receipts, so lost acknowledgements and process replacement
can reconcile without repeating mutations. The private methods are not advertised
as browser/agent actions. `inspectQuiescence()` exposes bounded coordinator status.

While held, ordinary list/inspect/session reads do **not** repair the catalog.
They return its current projection; `coverage.projection` (or selected inspection
`projection`) declares `held`, `complete`, and `repairDeferred`. Release permits
future normal reads to repair the projection. Exact command receipts remain
passive. An unknown mkdir result retained after a dead process is historical
uncertainty, not running work: it remains unknown and can never be replayed.
An active durable maintenance fence survives that restart and still blocks writes.

## Directory picker and shared defaults

`locations.list` accepts `{path?,directoriesOnly?,controlId?,limit?,cursor?}`.
It returns `{path,parent,entries,revision,nextCursor?,truncated,coverage}`.
Each entry is `{name,path,directory}`; default `directoriesOnly:true`, at most100
entries per page, sorted directories first then name. Parent is null at the
configured authorization edge. Only the selected directory is enumerated; there
is no recursive walk, file-body read, session discovery, or agent startup. Hidden
entries and symbolic links are explicitly omitted. At most10000 directory entries
are examined; exceeding the budget returns `directory_scan_budget` rather than
an apparently complete partial list. Only a page-size heap is retained. Cursors
bind the client, path, filter, directory identity/change stamp and expire after5
minutes; a changed directory requires a fresh first page. Outside-root paths and
symlink targets cannot broaden visibility. Picker and selection state stay local.

`locations.create {path,name,controlId?}` creates one child of an existing authorized
parent. The name is preserved, with no slug conversion. It never registers a
workspace, opens a chat, adopts an existing folder, or overwrites files. The same
reserved-command and pinned-directory allocation contract applies; inspect via
`workspace.receipt` after uncertain completion. A confirmed result returns
`{path,parent,entries:[],truncated:false,createdBy,directoryIdentity,registered:false}`.

`workspace.defaults {}` reads `{defaultRoot,configRevision,creationSupported}`.
`workspace.defaults.set {defaultRoot,expectedConfigRevision}` edits the shared
owner-backed default at its exact revision and returns an ordinary durable command
receipt. Empty string resets to the launcher's authorized default. Missing roots
are permitted for later prepared creation; no filesystem creation occurs while
saving a default. Changes invalidate older prepared plans, survive owner restart,
and cannot escape the configured allowed roots. `showPaths` remains client-local.

`workspace.sessions` accepts `archive:'active'|'all'|'archived'`, default active.
Omitting `id` searches across the owner's authorized existing visible workspaces;
providing it restricts the same query to one workspace. An invalid explicit ID is
refused and never falls back to a global query. The standard AHP `listSessions`
schema is unchanged; this additional filter surface is negotiated as an extension.
The workspace topic and list result advertise
`sessionQuery:{global:true,archive:true,search:true}` so clients can discover these
filters without assuming an older owner accepts an omitted ID.
All selectors continue to exclude missing, unknown, hidden and native-deleted
workspaces/sessions **before pagination**. Root sessions remain the default;
children require an explicit parent. Archive flags come from host-authoritative
organization projection, never native-history interpretation. This requires the
catalog archive-filter API and host archive projection support; it does not use
the older `includeArchive` flag, which has broader historical-directory semantics.

All new mkdir/default mutations participate in the held owner gate. Directory
listing and default reads are explicitly passive and remain available while held.

## Validation

```sh
uv sync --project python --extra test
python/.venv/bin/python -m pytest python/tests
npm ci
npm test
```

For installed cross-package acceptance set WORKSPACE_OWNER_PYTHON to a fresh
Python environment containing the built owner wheel, CATALOG_EXECUTABLE to the
installed catalog executable, and HOST_MODULE to the installed host dist/index.js.
`npm test` then requires the public installed composition case instead of skipping
it. Tests cover crash-after-mkdir recovery, name races, stale revision/config,
symlink/outside-root refusal, lease exclusion, held catalog/mkdir lifetimes, passive held reads, exact release acknowledgement loss and restart reconciliation, display-only rename, removed history
preservation, bounded projection rebuild, root/child pages, and zero agent starts.
Browser interaction is qualified by the independently owned web-client lane;
these package tests do not claim browser, device, or production deployment.

## Persistent service fences

The trusted quiescence participant advertises `serviceStop: {version: 1}` only
for the retained service-stop contract. Acquisition copies the complete
`serviceIdentity` (`installationId`, `dataScope`, `ownerId`, `instanceId`,
`releaseDigest`) into its existing durable intake fence. Restarting does not
open intake or replay admitted work. Python owners require the installed
Foundation `DurableIntakeFence.SERVICE_STOP_VERSION` marker.

Release requires the host-authenticated `kind: 'service-lifecycle'` proof bound
to the exact fence, command, original identity, and observed instance. A resumed
service needs distinct-instance exit/readiness receipts; a refused stop needs
the exact original-instance refusal receipt. The complete proof is retained.
Exact completed retries are passive, and changed proofs refuse even as the first
request after restart. Generic recovery/update proofs do not release this fence.

An `admission-refused` rollback is restricted to the newly acquired live lease.
It is unavailable through reconciliation or after an unknown outcome. Reads of
existing receipts stay available while intake is held. Platform authentication,
process ownership, stop/resume signaling, and aggregate coverage remain with the
host and supervisor; this owner does not infer them from a PID or missing socket.

The distribution's installed owner-service matrix covers fresh reopen, changed
proof, unknown rollback, and public bridge behavior on Node22/Python311+313.


## Held retention inspection

The actual quiescence participant advertises `retentionHide: {version: 1}`.
Acquire it with purpose `retention-hide` and the exact coordinator fence context.
The returned live lease exposes
`inspectRetentionReferences({sessions: ["ahp-session:/..."], limit: 101})`.
The family must contain 1–101 distinct explicit session URIs. The result is
`{coverage: "complete" | "partial", protected: [{session, reasons}], omissions}`.
Only the original held lease can inspect; release, uncertainty or replacement
invalidates that authority. Release reconciliation requires the same authenticated
coordinator proof and never retries effects. A pre-effect admission rollback is
allowed only on the original live lease. The purpose grants no mutation rights.

Inspection reads bounded indexed owner metadata while intake remains closed.
It never starts a native worker, scans canonical histories, deletes product records,
or interprets absence of a runtime as absence of deferred work. `complete` describes
this owner's reference coverage, not permission to hide or delete a conversation.
The coordinator must hold every configured owner, check all results, and use the
native history owner's separate preservation-first hide boundary.

Active work blocks acquisition. Retained uncertain owner commands protect their explicitly associated conversations; unscoped uncertainty cannot produce a false absence proof.

## Managed-file disposal protection

`quiescenceParticipant.managedFiles = {version: 1, preservesCanonical: true}` is a separate contract from `retentionHide`. It holds the real owner intake with purpose `managed-files-disposal`, preserving every owner record. The acquired lease exposes:

```ts
inspectManagedFilesReferences({
  sessions: [rootSession, ...descendants], // explicit AHP URIs, at most 101
  limit: 101,
  allocation: {allocationId, executionDirectory, allocationHash, treeHash, entryCount, bytes}
}) // {coverage: 'complete' | 'partial', protected: [{session, reasons}], omissions: [...] }
```

The allocation comes from the trusted host's native-reviewed managed allocation, never a browser path. It is bound with the exact selected family on the first inspection of the live lease; a different review is refused. This read does not grant file deletion. The coordinator must bind release to its exact durable managed-files effect receipt, keep unknown fences held, and refuse partial/protected coverage. Lease inspectors expire before release begins, including unknown release; admission-refused rollback is available only on the original live lease. Restart reconciliation requires the existing exact verified release proof.

Uncertain create/register commands protect the whole requested family. Every overlapping registration, including hidden and cross-conversation registrations, protects files. Indexed path queries and bounded ancestor lookups do not enumerate directories.

Inspection uses bounded selected metadata or indexed overlap probes, not native transcripts, a global history projection, or worker/model startup. Existing retention-hide and service-stop lifecycles are unchanged. The package tests cover the independently installed owner transport and held/unknown/exact-release behavior; full host/native/browser disposal acceptance remains a composition responsibility.

## Authority startup inspection

Under its existing owner lease, the Python owner checks existing authority schema read-only before writable authority connections. Missing required tables or columns, incompatible schema versions, and orphan WAL/SHM/journal files (including empty sidecars) refuse startup. A dangling or nonregular main/sidecar refuses too. Existing main and WAL/journal evidence is retained; SQLite may create its own SHM or empty WAL during read-only inspection. No historical row scan, startup hash, whole-database copy, mirror, or derived Catalog rebuild is added. Constructor refusal releases its lease.

The original d332263 profile already required meta, registrations, plans, and commands plus source/revision metadata. configSequence arrived at 9db6324; only a valid unversioned profile without saved-default or later retention-index evidence may introduce that missing key as zero. Marker 1 requires it. Saved source/revision are never regenerated on an existing damaged profile. Derived indexes remain reconstructible.

The reusable intake-fence database remains owned and checked by Foundation Operations. These checks certify fixed schema and bounded metadata, not every historical row or deleted whole-file authority. Native/model/account acceptance is separate from owned inert fixture checks.

## Pre-retirement distribution admission abort

The trusted Host participant forwards `abortAdmission(context_with_proof)` to the
private owner `quiescence.abortAdmission` route (slash form for workspace,
notifications and diagnostics). It negotiates `quiescence.admissionAbort.version=1`,
validates exact Host13 proof and typed owner receipt, and reports unsupported older
workers explicitly. The owner delegates to Foundation Operations' shared
`DurableIntakeFence` using its existing authority database, original acquisition or
refusal journal, and current active/background/pending accounting. No missing held
row, generic release proof or changed retry authorizes settlement. The private
`quiescence.admissionAbortReceipt` route observes an original completed receipt.

This is additive future-source support. Old deployed stageless/unrecorded attempts
remain unknown. Actual authenticated Updates proof, complete composition and live
adoption require independent qualification; this adapter does not reopen intake by
itself. Feedback's Python participant is only one subowner; its Node aggregate and
resources-upload participant require separate complete attempted-subowner receipts.

A Node-local busy admission persists its original refusal through private
`quiescence/refuseAdmission` before returning `null`. The Python gate records
that exact distribution acquisition attempt with pending work; a later retry
cannot turn the original refusal into acquisition. Other purposes retain their
existing behavior.

## Optional live library query v1

When composition supplies the trusted Host `libraryQuery` callback, action schemas
and sessionQuery advertise version1. `workspace.sessions` then accepts
libraryQueryVersion:1, sort=activity|created|name, activity=all|working|attention,
location=all|managed plus existing scope/search/archive/page arguments. Without
that binding the new selectors are unavailable, rather than silently ignored.
Owner-configured roots and selected existing registrations stay authoritative;
Host intersects grants and supplies independent managed authorization.

Returned pages carry server-selected membership/order, countsAvailable:false,
observationFreshness and paging:live. Summary `_meta.amplifier.dev/catalog.activity`
distinguishes runtime unknown from retained uncertain effect/error. Cold/native-only
rows do not acquire a Needs attention flag. The negotiated metadata must be consumed
by clients; plain legacy sessions retain their original mapping. Current selected
AHP state remains authoritative. An available:false/refreshRequired:true result means
keep displayed pages and refresh explicitly, not a zero-match success. Global exact
counts and frozen-page guarantees are relaxed for this optional version only.

Source tests qualify component and composed fixtures separately. This change alone
does not qualify Web rendering, installed packages or the first recovery checkpoint.

The trusted launcher may negotiate `missingWorkspaceHistory` only after Catalog
advertises `missingWorkspaceHistory.version: 1`. This adds an explicit `missing`
location selector for retained ordinary-folder history. The ordinary library,
workspace registration, execution authority and independent visibility rules do
not change. Installed browser coverage lives in the Web owner's
`missing-workspace-history-browser.mjs`.

Maintenance release drains already admitted workspace projection reads before forwarding its exact proof. New refreshes wait behind that bounded release; mutations remain fenced. A timeout keeps protection held and never retries the release or the underlying operation.

## Workspace archive

Composition enables `workspaceArchive` only when Catalog advertises
`workspaceArchive.version: 1`. The shared `workspace.archive` and
`workspace.restore` actions require the displayed registration revision and a
durable command identity. Archiving affects workspace navigation only: chats,
running work, files, and the stored pin order remain intact. Restoring a workspace
returns its pin to its retained position. Old pin-order requests are rejected.

`workspace.list` accepts `archive: active|archived|all` under this negotiation;
the selector is part of the paging cursor scope. Archive state lives in additive
SQLite tables, so older readers keep their existing table layout. Older catalog
projections that omit the flag preserve it. Main workspace migration copies the
effective archive flag along with names and pins without changing the source.

### Shared-history reference checks

The existing held reference inspector is also available under an exact Recovery hold through `recoveryReferences: { version: 1 }`. It checks bounded explicit conversation identities without starting execution or granting history-deletion authority. Expired holds and incomplete or protected references refuse cleanup; owner records and uncertain receipts remain retained.

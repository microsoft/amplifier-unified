# MCP owner contributor entry

Read [local vision](docs/VISION.md), [owner contract v1](contracts/mcp-owner.v1.md)
and [README](README.md) before changing behavior. They apply the approved family
direction and reference upstream/owner authority; they do not ratify new scope.

Change only this repository in an owned checkout/state root. Preserve native
history, original artifacts, identities and unknown receipts. Never replay work
or infer safe remote retirement from disconnect. No real external-effect tools,
real provider consent, package publication, merge or deployment without applicable
user authorization. Keep existing host/client/native/resources ownership intact.

For a shared semantic change, identify the inherited clause, producer/consumers,
falsifier and acceptance boundary and coordinate with the authority owner. Keep
exact executable schemas as the field authority. Review every known affected
Amplifier module implementation before a module-class change; this optional
broker does not replace the native module or Core/Foundation runtime.

Run checks appropriate to changed behavior; documentation-only changes require
link/source/manifest validation, not unnecessary runtime reruns. Record source,
installed package, fixtures, actual accounts/browser and adoption separately.
Do not rewrite sealed evidence or claim a documentation successor reran it.

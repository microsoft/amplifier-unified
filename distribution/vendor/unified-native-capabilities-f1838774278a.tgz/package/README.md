# Unified native capabilities

Optional `HostConfig.capabilities` provider for native Amplifier settings and
runtime controls. The generic AHP host remains unaware of Python objects or
Amplifier transcript/configuration files. All runtime calls cross negotiated
ACP `_amplifier/native`; setup calls cross optional `_amplifier/admin`.

```ts
import {AdminConnection,createNativeCapabilities} from '@amplifier/unified-native-capabilities';
const admin = new AdminConnection({
  command:'/owned/amplifier-acp/.venv/bin/amplifier-acp',
  args:['--config','/owned/agent.json'], cwd:'/owned/workspace',
  resolveWorkspace:async context => context.session
    ? (await host.inspectSession(context.session.uri)).workingDirectory
    : '/owned/workspace',
});
const capabilities = createNativeCapabilities({
  nativeControl:(uri,op,args)=>host.nativeControl(uri,op,args),
  nativeAdmin:admin.perform,
  onInvalidate:(topic,scope)=>host.invalidateCapability(topic,scope),
});
// Supply capabilities to HostConfig before listen, with `host` assigned before use.
// Close admin explicitly when the distribution shuts down.
```

The trusted agent config must enable `adminWorkspaceRoots`. A client-provided
workspace remains a selector checked against the resolved trusted context.
Administration never calls session/new. No retries occur after timeout/crash;
the generic host owns durable admission receipts. Clients own editor drafts.

Reads are lazy, single-flight, copied, bounded to 32 cached scopes and 768 KiB per
topic, with a 15-second TTL. Commits invalidate only records; they do not rebuild
unrelated data. Global native administration invalidates affected cached scopes
through the optional public callback. Session execution controls require an
explicit negotiated native control advertisement. Standard ACP config options
remain the client/host's first choice for supported model/mode changes.

## Topic DTOs

- `configuration`: `configuration: {sessionId,plan,modules,capabilities,bundle,...}`,
  numeric `configurationRevision`, and bounded `registry` results. Bundle preview
  and switch selectors live inside that selected session's `configuration`.
- `provider-catalog`: `setup` (original provider/routing manager result), bounded
  per-provider metadata/catalogs and operation receipts; `draftDefaults` contains
  resolved choices keyed by workspace/bundle, never a user's editing state.
- `bundles`: native `bundles`, `registeredBundles`, `bundleDefaults`,
  `bundleDiscovery` when requested. No fabricated catalog when admin is absent.
- `runtime-control`: `runtimeControl[sessionURI][operation]`, plus the existing
  `modelCatalogs` selector. Goals, tasks, budgets, capacity, tools and advanced
  controls use native results without imitating an engine in TypeScript.

Actions use version 1 capability-action schema and durable `commandId`; the
returned `_meta['amplifier.dev/operation'].id` names the completed operation for
legacy UI selectors. Native errors propagate explicitly. Core functionality
works without installing this optional Unified presentation package.

## Validation

`npm test && npm run build`. Set `AMPLIFIER_ACP_PYTHON` to the installed adapter's
Python executable to run the actual upstream ACP SDK/native admin subprocess
test. Without it, that integration test is visibly skipped; it is never replaced
by a fake successful setup. Source tests and offline provider tests do not prove
live OAuth/model/account acceptance.

`actionSchemas()` lazily returns the advertised public action schemas without
opening a native worker or provider. Secret voice credential/configuration
operations are deliberately absent; they are trusted server-only admin calls.
Generic `runtime.control` cannot submit history edits/steering/scheduled or
observational input, relocate execution, run internal memory consolidation, or
bypass the owned process/kernel actions. Those actions need their corresponding
host admission/lifecycle owner. Native adapter support alone does not claim
Unified interactive parity for an unregistered owner. Tool invocation receives
actor provenance from authenticated context, never the argument body. The native
runtime retains its own generic-tool and approval-hook rechecks.

Full mount-plan edits require the native inspect result's opaque
`configuration.configurationRevision` hash as `expectedConfigurationRevision`.
This differs from the outer numeric topic `configurationRevision`. The bridge
passes the exact base through without refreshing/rebasing it and keeps fresh
native plan/revision fields authoritative over older bundle overlays. Native
explicit `configuration-conflict` plus `executed:false` becomes `accepted:false`
with `result:{applied:false,executed:false,reason,configurationRevision,message}`;
the configuration topic is invalidated lazily and the host records a known
refusal. Other transport/native errors still propagate as uncertain outcomes.
The client preserves a dirty draft and requires explicit review before another
apply command. Missing base revisions are known refusals before native mutation.

### Native administration quiescence

One shared `AdminConnection` can cover native settings and maintenance users via
its public `quiescenceParticipant` (default owner ID `native-admin`, configurable
with `AdminOptions.ownerId`). Register it as a required writer participant; map
all native-admin callback paths to that authority. The participant obtains an
actual held native lifecycle lease, including post-response provider sign-in and
cross-process admin writers. A cold connection starts only the passive ACP
adapter to obtain this proof, never a Core session. Legacy agents without the
negotiated lifecycle capability refuse acquisition.

For reviewed native recovery, compose the two independent gates:

```ts
withQuiescenceMaintenance: (input, work) =>
  host.withQuiescenceMaintenance(input, () =>
    admin.withMaintenanceFence(input, work))
```

The recovery callback may then use `admin.perform` on that same connection.
Only the exact matching recovery fence admits the maintenance namespace;
ordinary configuration/generation mutations remain closed. Detached promises
lose this privilege when the trusted callback returns. The trusted reset preview
may pass its already-resolved native history cwd only inside this fence; generic
client administration cannot select native paths.

`inspectLifecycle()` supplies bounded native-owned activity and lease identity.
A participant known refusal means acquisition caused no effect; loss or timeout
retains uncertainty. Release requires the host's authenticated exact proof.
Replacement reconciliation acquires fresh native OS writer proof before release;
a new process alone does not prove an earlier operation completed. Multiple
independent participants for the same native home must be aggregated behind one
shared admin authority rather than trying to hold two exclusive leases.

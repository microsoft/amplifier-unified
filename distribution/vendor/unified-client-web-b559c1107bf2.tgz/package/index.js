import {fileURLToPath} from 'node:url';
export const webDirectory=fileURLToPath(new URL('./dist/',import.meta.url));
export default webDirectory;

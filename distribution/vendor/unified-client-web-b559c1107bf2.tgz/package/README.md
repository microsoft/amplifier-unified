# Amplifier Unified web client

Prebuilt static release. Import `webDirectory` from `@amplifier/unified-client-web` and pass it to your authenticated same-origin AHP gateway. Serve `/ahp` as the standard WebSocket endpoint; inject the authenticated account using `/connection.js`. No frontend build dependencies or source repositories are needed.

The release receipt records the exact source commit and asset hashes. Source development and fixture tests live in microsoft/amplifier-unified-client-web.

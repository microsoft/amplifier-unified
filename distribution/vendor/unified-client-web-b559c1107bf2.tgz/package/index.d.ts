export declare const webDirectory:string;
export default webDirectory;

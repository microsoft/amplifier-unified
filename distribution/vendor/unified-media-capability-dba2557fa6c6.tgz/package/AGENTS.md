# Media repository entry point

Read [VISION.md](VISION.md), [media contract v1](contracts/media.v1.md), and
[README.md](README.md) before changing this owner's public behavior. The contract
links the approved shared family direction and upstream authorities; its local
mapping is not permission to introduce or self-ratify new cross-owner semantics.

Keep edits within this repository and owned state. Host/native/client/distribution
ownership stays at the referenced seams. Preserve accepted and unknown work,
canonical native history and immutable artifacts; do not infer replay or deletion
rights from recovery, retention or disposal inspection.

Map a behavioral change to its contract promise, affected consumers, falsifier
and exact evidence. Use existing checks appropriate to the change. Documentation
only successors need link/drift and source-file equality checks, not new runtime
features or a relabeled prior package pass. Keep source, package, browser/device,
provider-account and deployed acceptance distinct. Real capture/provider calls
require an explicitly owned acceptance scenario.

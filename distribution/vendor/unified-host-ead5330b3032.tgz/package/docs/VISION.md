# Amplifier Unified Host vision

Status: repository-local expression of the family direction approved on
2026-10-02, recorded 2026-10-03. This describes the destination and obligations;
it does not certify every implementation, peer, deployment or performance target.
This packet introduces no new product direction or runtime feature.

The host makes accepted agent work durable and accessible from independent
clients without making historical existence a memory or execution cost. Clients
speak upstream AHP; agents speak upstream ACP. Amplifier is one configured agent
implementation, with its native Core/Foundation composition behind its adapter.
The host must remain useful without importing that runtime or its private files.

A conversation retains one engine/native identity and one execution authority.
Multiple authorized viewers can observe it. Closing every view does not cancel
accepted work, and opening an old view does not mount its agent. A connection,
subscription, catalog row and active execution are different facts.

Attention determines the normal working set: filtered catalog pages, selected
resources, bounded views, active work and unresolved decisions. Small updates
visit their actual dependencies and subscribers. Unsent drafts, selection,
editing buffers and presentation caches remain client-owned; explicit targeted
client tools do not turn them into a global synchronized state object.

Recovery must tell the truth. Admission, completed effects and unknown outcomes
are distinct. Loss of a connection or cache is not permission to replay a prompt,
permission decision, device operation or uncertain command. Native history and
retained events remain under native ownership; a rebuildable catalog is not a
second resume authority.

Optional capability owners carry their own authorization, storage, receipts and
held lifetime proofs. Packaging them with the host does not transfer their
semantics to host core. An unsupported peer or missing owner is an explicit
limitation, never a silent replacement action or invented idle proof.

Independent development is a product requirement. A host contributor must be
able to run official AHP clients and a standalone ACP fixture using private state
and no live account. Integration, actual vendor/account/device behavior and
fresh deployed runtime adoption require separate evidence.

## Authority and change discipline

The approved [family vision][family] and its [HP][hp], [WS][ws] and [CB][cb]
contracts are inherited direction. Upstream protocol definitions override local
wire descriptions. The local [host boundary v1](contracts/host-boundary.v1.md)
maps those obligations to this repository's public seams and falsifiers.

README behavior and tests describe implementation; they do not silently amend
that direction. A proposal that changes identity, scope, durability, history
ownership or protocol meaning must be labeled as a proposal, identify affected
owners and consumers, and update the owning family contract before adoption.
Unverified acceptance and missing features belong in the evidence/gap record.

The family [status ledger][status] and [feature migration ledger][features] own
cross-repository completion claims. This repository's contract links local
acceptance entrypoints and states their qualification limits. There is no claim
that a source test proves an installed package, Linux service handoff, browser,
physical device, authenticated vendor turn or production deployment.

[family]: https://github.com/microsoft/amplifier-unified/blob/main/docs/architecture/VISION.md
[hp]: https://github.com/microsoft/amplifier-unified/blob/main/contracts/host-protocol.v1.md
[ws]: https://github.com/microsoft/amplifier-unified/blob/main/contracts/working-set.v1.md
[cb]: https://github.com/microsoft/amplifier-unified/blob/main/contracts/component-boundaries.v1.md
[status]: https://github.com/microsoft/amplifier-unified/blob/main/docs/architecture/implementation-status.md
[features]: https://github.com/microsoft/amplifier-unified/blob/main/docs/architecture/feature-migration.csv
